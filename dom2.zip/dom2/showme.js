document.getElementById("btn1").addEventListener("click", function() {
    toggleVisibility("img1");
});

document.getElementById("btn2").addEventListener("click", function() {
    toggleVisibility("img2");
});

document.getElementById("btn3").addEventListener("click", function() {
    toggleVisibility("img3");
});

// Event Listeners para las imágenes
document.getElementById("img1").addEventListener("click", function() {
    hideImage("img1");
});

document.getElementById("img2").addEventListener("click", function() {
    hideImage("img2");
});

document.getElementById("img3").addEventListener("click", function() {
    hideImage("img3");
});

// Función para mostrar u ocultar una imagen
function toggleVisibility(imageId) {
    var image = document.getElementById(imageId);
    image.classList.toggle("oculto");
}

// Función para ocultar una imagen al hacer clic en ella
function hideImage(imageId) {
    var image = document.getElementById(imageId);
    image.classList.add("oculto");
}