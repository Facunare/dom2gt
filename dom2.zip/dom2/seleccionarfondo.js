const input = document.querySelector('#input')
const body = document.querySelector('.bodyBg')


document.addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {

        if(input.value == 'rojo' || input.value == 'amarillo' || input.value == 'azul'){
            switch(input.value){
                case 'rojo': body.style.backgroundColor = 'red'
                break
                case 'amarillo': body.style.backgroundColor = 'yellow'
                break
                case 'azul': body.style.backgroundColor = 'blue'
            }
        }else{
            console.log("No es un color primario o no esta en español")
        }

    }else if(event.key === 'Delete' || event.key === 'Backspace'){
        body.style.backgroundColor = 'white'
    }
  });
  