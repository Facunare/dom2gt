const body = document.querySelector('.mouseBody')
mousePresionado = false

document.body.addEventListener('mousedown', function() {
    mousePresionado = true
  })
  
  document.body.addEventListener('mouseup', function() {
    mousePresionado = false
  })
  
body.addEventListener('mousemove', (e)=>{
    if(mousePresionado){

        const img = document.querySelector('.gif')
        img.style.top = e.clientY + 'px'
        img.style.left = e.clientX + 'px'
    }
})

