const boton = document.querySelector('.botonBeep')
const body = document.querySelector('body')
boton.addEventListener('click', seEjecutaEnEvento)

function seEjecutaEnEvento(){
    body.appendChild(document.createElement('p'))
    body.classList.toggle('color')
    let parrafo = document.querySelector('p')
    parrafo.innerHTML = "BEEP"
}
