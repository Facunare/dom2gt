const auto1 = document.querySelector('#auto1');
const auto2 = document.querySelector('#auto2');
const auto3 = document.querySelector('#auto3');
const auto4 = document.querySelector('#auto4');

const autos = [
  { auto: auto1, acumulador: 0 },
  { auto: auto2, acumulador: 0 },
  { auto: auto3, acumulador: 0 },
  { auto: auto4, acumulador: 0 }
];

const pista = document.querySelector('.autos');

document.addEventListener('keyup', auto);

function auto(event) {
  if (event.key === 'Enter') {
    moverAuto(autos[0]);
  } else if (event.key === 'Backspace') {
    moverAuto(autos[1]);
  } else if (event.key === 'a') {
    moverAuto(autos[2]);
  } else if (event.key === 'b') {
    moverAuto(autos[3]);
  }
}

function moverAuto(auto) {
  auto.acumulador += 70;
  auto.auto.style.marginLeft = `${auto.acumulador}px`;
  if (auto.acumulador >= pista.offsetWidth - auto.auto.offsetWidth) {
    alert(`¡El vehículo ${auto.auto.id} ganó la carrera!`);
  }
}
