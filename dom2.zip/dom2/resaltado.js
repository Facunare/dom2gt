
const paragraph = document.querySelectorAll('p')
for(let p of paragraph){
    p.addEventListener('click', function(){
        this.classList.toggle('resaltado')
    })
}

const magia = document.getElementById('magia')
const fotarda = document.querySelector('.fotarda')
magia.addEventListener('mouseover', ()=>{
    fotarda.style.display = "none"
})

